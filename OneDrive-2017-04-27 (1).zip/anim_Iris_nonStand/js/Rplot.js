(function($) {
    $(document).ready(function() {
	$.fn.scianimator.defaults.theme = 'dark';
	$('#Rplot').scianimator({
	    'images': ['IMG_perceptron2d_Iris/Rplot1.png', 'IMG_perceptron2d_Iris/Rplot2.png', 'IMG_perceptron2d_Iris/Rplot3.png', 'IMG_perceptron2d_Iris/Rplot4.png', 'IMG_perceptron2d_Iris/Rplot5.png', 'IMG_perceptron2d_Iris/Rplot6.png', 'IMG_perceptron2d_Iris/Rplot7.png', 'IMG_perceptron2d_Iris/Rplot8.png', 'IMG_perceptron2d_Iris/Rplot9.png', 'IMG_perceptron2d_Iris/Rplot10.png', 'IMG_perceptron2d_Iris/Rplot11.png', 'IMG_perceptron2d_Iris/Rplot12.png', 'IMG_perceptron2d_Iris/Rplot13.png', 'IMG_perceptron2d_Iris/Rplot14.png', 'IMG_perceptron2d_Iris/Rplot15.png', 'IMG_perceptron2d_Iris/Rplot16.png', 'IMG_perceptron2d_Iris/Rplot17.png', 'IMG_perceptron2d_Iris/Rplot18.png', 'IMG_perceptron2d_Iris/Rplot19.png', 'IMG_perceptron2d_Iris/Rplot20.png', 'IMG_perceptron2d_Iris/Rplot21.png', 'IMG_perceptron2d_Iris/Rplot22.png', 'IMG_perceptron2d_Iris/Rplot23.png', 'IMG_perceptron2d_Iris/Rplot24.png', 'IMG_perceptron2d_Iris/Rplot25.png', 'IMG_perceptron2d_Iris/Rplot26.png', 'IMG_perceptron2d_Iris/Rplot27.png', 'IMG_perceptron2d_Iris/Rplot28.png', 'IMG_perceptron2d_Iris/Rplot29.png', 'IMG_perceptron2d_Iris/Rplot30.png'],
	    'width': 1500,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#Rplot').scianimator('play');
    });
})(jQuery);
